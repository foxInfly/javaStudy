package com.gupaoedu.vip.pattern.facade.general;

// 子系统
public class SubSystemC {
    public void doC() {
        System.out.println("doing C stuff");
    }
}