package com.gupaoedu.vip.pattern.facade.points;

/**
 * Created by Tom.
 */
public class GiftInfo {

    private String name;

    public GiftInfo(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
