package com.gupaoedu.vip.pattern.facade.general;

// 子系统
public class SubSystemA {
    public void doA() {
        System.out.println("doing A stuff");
    }
}