package com.gupaoedu.vip.pattern.facade.general;

// 子系统
public class SubSystemB {
    public void doB() {
        System.out.println("doing B stuff");
    }
}