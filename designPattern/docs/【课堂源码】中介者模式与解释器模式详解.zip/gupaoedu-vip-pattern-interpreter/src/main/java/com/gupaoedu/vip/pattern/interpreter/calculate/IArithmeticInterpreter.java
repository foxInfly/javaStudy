package com.gupaoedu.vip.pattern.interpreter.calculate;

public interface IArithmeticInterpreter {
    int interpret();
}