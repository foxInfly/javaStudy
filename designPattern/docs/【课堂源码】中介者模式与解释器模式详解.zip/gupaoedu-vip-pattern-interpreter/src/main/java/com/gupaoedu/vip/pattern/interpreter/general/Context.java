package com.gupaoedu.vip.pattern.interpreter.general;

import java.util.HashMap;

// 上下文环境类
public class Context extends HashMap {

}