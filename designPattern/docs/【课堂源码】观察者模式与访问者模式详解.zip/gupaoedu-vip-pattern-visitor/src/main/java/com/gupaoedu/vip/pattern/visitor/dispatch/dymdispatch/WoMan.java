package com.gupaoedu.vip.pattern.visitor.dispatch.dymdispatch;

/**
 * Created by Tom.
 */
public class WoMan implements Person {

    public void test() {
        System.out.println("女人");
    }
}
