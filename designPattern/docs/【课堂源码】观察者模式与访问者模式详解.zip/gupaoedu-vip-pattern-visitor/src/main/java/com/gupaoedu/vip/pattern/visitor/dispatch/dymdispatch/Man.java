package com.gupaoedu.vip.pattern.visitor.dispatch.dymdispatch;

/**
 * Created by Tom.
 */
public class Man implements Person {

    public void test() {
        System.out.println("男人");
    }
}
