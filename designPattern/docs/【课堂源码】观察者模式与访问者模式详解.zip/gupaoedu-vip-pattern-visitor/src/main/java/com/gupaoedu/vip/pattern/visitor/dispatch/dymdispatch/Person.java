package com.gupaoedu.vip.pattern.visitor.dispatch.dymdispatch;

/**
 * Created by Tom.
 */
public interface Person {
    void test();
}
