package com.gupaoedu.vip.pattern.observer.mouseevent.core;

import com.gupaoedu.vip.pattern.observer.mouseevent.core.Event;

/**
 * 观察者抽象
 * Created by Tom.
 */
public interface EventListener {

}
