package com.gupaoedu.vip.pattern.observer.mouseevent.handler;

/**
 * Created by Tom.
 */
public interface MouseEventType {
    String ON_CLICK = "click";

    String ON_MOVE = "move";
}
