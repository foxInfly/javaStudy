package com.gupaoedu.vip.pattern.strategy.general;

//抽象策略类 Strategy
public interface IStrategy {
    void algorithm();
}