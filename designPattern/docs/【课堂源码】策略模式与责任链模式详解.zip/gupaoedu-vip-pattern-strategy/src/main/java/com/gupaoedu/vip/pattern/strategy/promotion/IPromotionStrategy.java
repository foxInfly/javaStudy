package com.gupaoedu.vip.pattern.strategy.promotion;

/**
 * Created by Tom.
 */
public interface IPromotionStrategy {
    void doPromotion();
}
