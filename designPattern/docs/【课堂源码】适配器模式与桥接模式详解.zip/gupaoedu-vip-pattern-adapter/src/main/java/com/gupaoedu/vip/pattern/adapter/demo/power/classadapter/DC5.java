package com.gupaoedu.vip.pattern.adapter.demo.power.classadapter;

/**
 * Created by Tom.
 */
public interface DC5 {
    int output5V();
}
