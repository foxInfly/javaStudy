package com.gupaoedu.vip.pattern.adapter.demo.power.interfaceadapter;

/**
 * Created by Tom.
 */
public interface DC {
    int output5V();
    int output12V();
    int output24V();
    int output36V();
}
