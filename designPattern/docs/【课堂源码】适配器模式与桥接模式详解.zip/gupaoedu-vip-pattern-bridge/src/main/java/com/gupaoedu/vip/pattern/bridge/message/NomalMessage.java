package com.gupaoedu.vip.pattern.bridge.message;

/**
 * Created by Tom.
 */
public class NomalMessage extends AbastractMessage {
    public NomalMessage(IMessage message) {
        super(message);
    }
}
