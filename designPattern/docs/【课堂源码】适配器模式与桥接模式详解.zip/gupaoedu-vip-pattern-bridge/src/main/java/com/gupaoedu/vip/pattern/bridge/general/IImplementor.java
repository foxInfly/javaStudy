package com.gupaoedu.vip.pattern.bridge.general;

// 抽象实现
public interface IImplementor {
    void operationImpl();
}
