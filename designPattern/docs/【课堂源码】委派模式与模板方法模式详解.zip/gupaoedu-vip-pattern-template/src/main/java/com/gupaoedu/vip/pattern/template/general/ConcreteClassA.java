package com.gupaoedu.vip.pattern.template.general;

// 具体实现类A
public class ConcreteClassA extends AbstractClass {
    @Override
    protected void step1() {
        System.out.println("ConcreateClassA:step1");
    }
}