package com.gupaoedu.vip.pattern.template.course;

/**
 * Created by Tom.
 */
public class PythonCourse extends AbastractCourse {
    protected void checkHomework() {
        System.out.println("检查Python作业");
    }
}
