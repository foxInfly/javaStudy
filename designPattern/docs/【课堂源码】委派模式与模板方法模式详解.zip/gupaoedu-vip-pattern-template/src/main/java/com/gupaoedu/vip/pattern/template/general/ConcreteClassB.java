package com.gupaoedu.vip.pattern.template.general;

// 具体实现类B
public class ConcreteClassB extends AbstractClass {
    @Override
    protected void step2() {
        System.out.println("ConcreateClassB:step2");
    }
}