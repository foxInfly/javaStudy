package com.gupaoedu.vip.pattern.delegate.general;

public interface Task {
    void doTask();
}