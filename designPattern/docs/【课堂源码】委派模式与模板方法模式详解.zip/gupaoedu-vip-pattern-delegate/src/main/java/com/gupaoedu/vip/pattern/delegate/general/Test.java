package com.gupaoedu.vip.pattern.delegate.general;

public class Test {
    public static void main(String[] args) {
        new Delegate().doTask();
    }
}