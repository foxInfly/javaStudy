package com.gupaoedu.vip.pattern.delegate.general;

public class ConcreteB implements Task {
    public void doTask() {
        System.out.println("执行 , 由B实现");
    }
}