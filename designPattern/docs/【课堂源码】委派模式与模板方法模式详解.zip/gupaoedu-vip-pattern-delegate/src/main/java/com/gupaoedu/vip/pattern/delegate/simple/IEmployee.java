package com.gupaoedu.vip.pattern.delegate.simple;

/**
 * Created by Tom.
 */
public interface IEmployee {
    void doing(String task);
}
