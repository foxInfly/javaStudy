package com.gupaoedu.vip.pattern.delegate.mvc.controllers;

/**
 * Created by Tom.
 */
public class SystemController {

    public void logout(){

    }

}
