package com.gupaoedu.vip.pattern.state.general.simple;

//抽象状态：State
public interface IState {
    void handle();
}