package com.gupaoedu.vip.pattern.state.gper;

/**
 * Created by Tom.
 */
public class Test {
    public static void main(String[] args) {
        AppContext context = new AppContext();
        context.favorite();
        context.comment("评论：好文章，360个赞");
    }
}
